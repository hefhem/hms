# Workflows (BPMN placeholders)

Place BPMN diagrams (PNG + JSON) here representing:
- OPD visit
- IPD admission
- Lab/Radiology orders to results
