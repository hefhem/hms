# Frontend Apps (Angular skeleton)

Apps to scaffold:
- admin-app
- staff-app
- patient-portal

Shared UI library (Storybook recommended). Configure OIDC login against Keycloak/Identity provider.
