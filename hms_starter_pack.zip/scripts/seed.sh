#!/usr/bin/env bash
echo 'Seed script placeholder. Implement EF Core seeders and call here.'
